// BUG: multiplies by 10 instead of summing quantity*price
import fs from "node:fs";
const rows = fs.readFileSync(new URL("./data/sales.csv", import.meta.url), "utf8")
  .trim().split("\n").slice(1);
let total = 0;
for (const line of rows) {
  const [,, qty, price] = line.split(",");
  total += Number(qty) * 10; // should be Number(qty) * Number(price)
}
fs.writeFileSync(new URL("./out/total.txt", import.meta.url), total.toFixed(2) + "\n");
